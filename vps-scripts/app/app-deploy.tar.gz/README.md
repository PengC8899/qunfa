# Telegram 群发控制面板

使用 FastAPI + Telethon 实现的 Telegram 账号群发控制后台，提供简单 Web 面板勾选群组并发送消息。

## 环境要求

- Python 3.10+

## 安装与运行

```bash
git clone <repo_url>
cd project_root
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# 编辑 .env 填入 TG_API_ID, TG_API_HASH, TG_SESSION_NAME, ADMIN_TOKEN 等
uvicorn main:app --host 0.0.0.0 --port 8000
```

首次运行时 Telethon 会在当前目录创建 `.session` 文件，请确保已通过手机验证码完成登录（本项目假设会话已授权）。

## 访问后台

- 浏览器访问 `http://<服务器IP>:8000/`
- 在页面顶部输入并保存 `X-Admin-Token`，随后即可获取群列表与发送消息
- 所有 `/api/*` 接口均需在请求 Header 携带 `X-Admin-Token`

## 注意事项

- 大量群组发送时设置合理的 `delay_ms`，建议 1000–3000ms
- 请勿用于垃圾广告，否则账号可能受限