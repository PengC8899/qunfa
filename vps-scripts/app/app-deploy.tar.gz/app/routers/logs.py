from fastapi import APIRouter, HTTPException, Depends
from starlette.requests import Request
from sqlalchemy.orm import Session
from app.config import CONFIG
from app.database import get_db
from app.models import SendLog


router = APIRouter()


@router.get("/logs")
def recent_logs(request: Request, limit: int = 50, db: Session = Depends(get_db)):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="Unauthorized")
    rows = (
        db.query(SendLog)
        .order_by(SendLog.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": r.id,
            "group_id": r.group_id,
            "group_title": r.group_title,
            "message_preview": r.message_preview,
            "status": r.status,
            "error": r.error,
            "created_at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in rows
    ]