import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    ADMIN_TOKEN: str
    DB_URL: str
    HOST: str
    PORT: int
    ACCOUNTS: dict
    DEFAULT_ACCOUNT: str
    SESSION_DIR: str

    def __init__(self):
        admin_token = os.getenv("ADMIN_TOKEN") or os.getenv("ADMIN_PASSWORD")
        if not admin_token:
            raise RuntimeError("Missing ADMIN_TOKEN in .env")
        self.ADMIN_TOKEN = admin_token
        self.DB_URL = os.getenv("DB_URL", "sqlite:///./data.db")
        self.HOST = os.getenv("HOST", "0.0.0.0")
        self.PORT = int(os.getenv("PORT", "8000"))
        self.SESSION_DIR = os.getenv("SESSION_DIR", ".")

        accounts_list = (os.getenv("TG_ACCOUNTS") or "").strip()
        accounts: dict = {}
        if accounts_list:
            names = [x.strip() for x in accounts_list.split(",") if x.strip()]
            for name in names:
                api_id = os.getenv(f"TG_{name}_API_ID") or os.getenv("TG_API_ID")
                api_hash = os.getenv(f"TG_{name}_API_HASH") or os.getenv("TG_API_HASH")
                session_name = os.getenv(f"TG_{name}_SESSION_NAME") or os.getenv("TG_SESSION_NAME") or name
                if not api_id or not api_hash:
                    raise RuntimeError(f"Missing TG_{name}_API_ID/TG_API_ID or TG_{name}_API_HASH/TG_API_HASH in .env")
                accounts[name] = {
                    "api_id": int(api_id),
                    "api_hash": api_hash,
                    "session_name": session_name,
                }
            self.DEFAULT_ACCOUNT = names[0]
        else:
            api_id = os.getenv("TG_API_ID")
            api_hash = os.getenv("TG_API_HASH")
            session_name = os.getenv("TG_SESSION_NAME")
            if not api_id or not api_hash or not session_name:
                raise RuntimeError("Missing TG_API_ID, TG_API_HASH, TG_SESSION_NAME in .env")
            accounts[session_name] = {
                "api_id": int(api_id),
                "api_hash": api_hash,
                "session_name": session_name,
            }
            self.DEFAULT_ACCOUNT = session_name

        self.ACCOUNTS = accounts


CONFIG = Settings()