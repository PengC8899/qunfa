from sqlalchemy import Column, Integer, String, DateTime, Text
from sqlalchemy.sql import func
from app.database import Base


class SendLog(Base):
    __tablename__ = "send_logs"

    id = Column(Integer, primary_key=True, index=True)
    account_name = Column(String(64), index=True)
    group_id = Column(Integer, index=True)
    group_title = Column(String(255))
    message_preview = Column(Text)
    status = Column(String(32))
    error = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())