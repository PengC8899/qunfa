from app.telegram_client import MultiTelegramManager


async def get_groups(manager: MultiTelegramManager, account: str, only_groups: bool = True):
    return await manager.get_joined_groups(account, only_groups=only_groups)