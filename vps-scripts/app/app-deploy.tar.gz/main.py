from starlette.applications import Starlette
from starlette.staticfiles import StaticFiles
from starlette.templating import Jinja2Templates
from starlette.responses import HTMLResponse, JSONResponse
from starlette.requests import Request
from app.config import CONFIG
from app.database import Base, engine
from sqlalchemy import text
from app.telegram_client import multi_manager
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import SendLog
from app.services.send_service import send_to_groups
from app.services.group_service import get_groups
import time
import uuid
import asyncio
import uuid
import asyncio

app = Starlette()

templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.middleware("http")
async def admin_token_middleware(request, call_next):
    token = request.headers.get("X-Admin-Token")
    request.state.admin_token = token
    response = await call_next(request)
    return response


@app.route("/")
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.route("/api/accounts")
async def list_accounts(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    return JSONResponse(list(CONFIG.ACCOUNTS.keys()))

@app.route("/api/groups")
async def list_groups(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    only_groups = request.query_params.get("only_groups", "true").lower() != "false"
    account = request.query_params.get("account") or CONFIG.DEFAULT_ACCOUNT
    try:
        data = await get_groups(multi_manager, account=account, only_groups=only_groups)
        return JSONResponse(data)
    except BaseException as e:
        msg = str(e).lower()
        if "not authorized" in msg or "session" in msg:
            return JSONResponse({"detail": "session_not_authorized"}, status_code=403)
        return JSONResponse({"detail": "internal_error"}, status_code=500)


@app.route("/api/send", methods=["POST"])
async def send(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    body = await request.json()
    group_ids = body.get("group_ids") or []
    message = (body.get("message") or "").strip()
    parse_mode = body.get("parse_mode") or "plain"
    disable_web_page_preview = bool(body.get("disable_web_page_preview", True))
    delay_ms = int(body.get("delay_ms", 1500))
    account = body.get("account") or CONFIG.DEFAULT_ACCOUNT
    request_id = body.get("request_id")
    ok, reason = _check_request_guard(token, request_id)
    if not ok:
        return JSONResponse({"detail": "Too Many Requests"}, status_code=429, headers={"Retry-After": "1"})
    if not group_ids or not message:
        return JSONResponse({"detail": "group_ids and message required"}, status_code=400)
    db: Session = SessionLocal()
    try:
        resp = await send_to_groups(multi_manager, db, account, group_ids, message, parse_mode, disable_web_page_preview, delay_ms)
        return JSONResponse(resp)
    finally:
        db.close()


@app.route("/api/test-send", methods=["POST"])
async def test_send(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    body = await request.json()
    group_ids = body.get("group_ids") or []
    message = (body.get("message") or "").strip()
    parse_mode = body.get("parse_mode") or "plain"
    disable_web_page_preview = bool(body.get("disable_web_page_preview", True))
    account = body.get("account") or CONFIG.DEFAULT_ACCOUNT
    request_id = body.get("request_id")
    ok, reason = _check_request_guard(token, request_id)
    if not ok:
        return JSONResponse({"detail": "Too Many Requests"}, status_code=429, headers={"Retry-After": "1"})
    if not group_ids or not message:
        return JSONResponse({"detail": "group_ids and message required"}, status_code=400)
    db: Session = SessionLocal()
    try:
        resp = await send_to_groups(multi_manager, db, account, group_ids, message, parse_mode, disable_web_page_preview, 0)
        return JSONResponse(resp)
    finally:
        db.close()


@app.route("/api/logs")
async def recent_logs(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    limit = int(request.query_params.get("limit", 50))
    db: Session = SessionLocal()
    try:
        rows = (
            db.query(SendLog)
            .order_by(SendLog.created_at.desc())
            .limit(limit)
            .all()
        )
        data = [
            {
                "id": r.id,
                "group_id": r.group_id,
                "group_title": r.group_title,
                "message_preview": r.message_preview,
                "status": r.status,
                "error": r.error,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in rows
        ]
        return JSONResponse(data)
    finally:
        db.close()


async def startup_event():
    Base.metadata.create_all(bind=engine)
    pass
    try:
        with engine.connect() as conn:
            cols = conn.execute(text("PRAGMA table_info('send_logs')")).fetchall()
            names = {c[1] for c in cols}
            if 'account_name' not in names:
                conn.execute(text("ALTER TABLE send_logs ADD COLUMN account_name VARCHAR(64)"))
                conn.commit()
    except Exception:
        pass


_REQ_IDS: dict[str, float] = {}
_LAST_TS: dict[str, float] = {}


def _check_request_guard(token: str, request_id: str | None, window_ms: int = 500):
    now = time.monotonic()
    # prune old ids
    for k, ts in list(_REQ_IDS.items()):
        if now - ts > 60:
            del _REQ_IDS[k]
    # duplicate id guard
    if request_id:
        if request_id in _REQ_IDS:
            return False, "duplicate"
        _REQ_IDS[request_id] = now
    # throttle by token
    last = _LAST_TS.get(token, 0.0)
    if now - last < (window_ms / 1000.0):
        _LAST_TS[token] = now
        return False, "too_frequent"
    _LAST_TS[token] = now
    return True, None

app.add_event_handler("startup", startup_event)

TASKS: dict[str, dict] = {}


@app.route("/api/send-async", methods=["POST"])
async def send_async(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    body = await request.json()
    group_ids = body.get("group_ids") or []
    message = (body.get("message") or "").strip()
    parse_mode = body.get("parse_mode") or "plain"
    disable_web_page_preview = bool(body.get("disable_web_page_preview", True))
    delay_ms = int(body.get("delay_ms", 1500))
    account = body.get("account") or CONFIG.DEFAULT_ACCOUNT
    request_id = body.get("request_id")
    ok, reason = _check_request_guard(token, request_id)
    if not ok:
        return JSONResponse({"detail": "Too Many Requests"}, status_code=429, headers={"Retry-After": "1"})
    if not group_ids or not message:
        return JSONResponse({"detail": "group_ids and message required"}, status_code=400)
    task_id = uuid.uuid4().hex[:12]
    TASKS[task_id] = {
        "status": "running",
        "total": len(group_ids),
        "success": 0,
        "failed": 0,
        "started_at": time.time(),
        "finished_at": None,
        "account": account,
    }
    asyncio.create_task(_run_send_task(task_id, account, group_ids, message, parse_mode, disable_web_page_preview, delay_ms))
    return JSONResponse({"task_id": task_id})


@app.route("/api/task-status")
async def task_status(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    task_id = request.query_params.get("task_id")
    if not task_id or task_id not in TASKS:
        return JSONResponse({"detail": "Not Found"}, status_code=404)
    return JSONResponse(TASKS[task_id])


async def _run_send_task(task_id: str, account: str, group_ids: list[int], message: str, parse_mode: str, disable_web_page_preview: bool, delay_ms: int):
    db: Session = SessionLocal()
    try:
        delay = max(delay_ms, 0) / 1000.0
        succ = 0
        fail = 0
        for gid in group_ids:
            ok, err = await multi_manager.send_message_to_group(
                account,
                group_id=gid,
                text=message,
                parse_mode=parse_mode,
                disable_web_page_preview=disable_web_page_preview,
            )
            status = "success" if ok else "failed"
            if ok:
                succ += 1
            else:
                fail += 1
            preview = message[:200]
            title = str(gid)
            db.add(
                SendLog(
                    account_name=account,
                    group_id=gid,
                    group_title=title,
                    message_preview=preview,
                    status=status,
                    error=None if ok else (err or "send_failed"),
                )
            )
            db.commit()
            TASKS[task_id].update({"success": succ, "failed": fail})
            if delay > 0:
                await asyncio.sleep(delay)
        TASKS[task_id].update({"status": "done", "finished_at": time.time()})
    except Exception:
        TASKS[task_id].update({"status": "done", "finished_at": time.time()})
    finally:
        db.close()
@app.route("/api/login/send-code", methods=["POST"])
async def login_send_code(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    body = await request.json()
    account = body.get("account") or CONFIG.DEFAULT_ACCOUNT
    phone = (body.get("phone") or "").strip()
    force_sms = bool(body.get("force_sms", False))
    if not phone:
        return JSONResponse({"detail": "phone required"}, status_code=400)
    data = await multi_manager.send_login_code(account, phone, force_sms)
    if data.get("ok"):
        return JSONResponse({"ok": True})
    if "retry_after" in data:
        return JSONResponse({"detail": "flood_wait", "retry_after": data["retry_after"]}, status_code=429)
    return JSONResponse({"detail": data.get("error", "send_failed")}, status_code=400)

@app.route("/api/login/confirm", methods=["POST"])
async def login_confirm(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    body = await request.json()
    account = body.get("account") or CONFIG.DEFAULT_ACCOUNT
    phone = (body.get("phone") or "").strip()
    code = (body.get("code") or "").strip()
    password = body.get("password") or None
    if not phone or not code:
        return JSONResponse({"detail": "phone and code required"}, status_code=400)
    data = await multi_manager.confirm_login(account, phone, code, password)
    return JSONResponse({"ok": True, "user": data})

@app.route("/api/account-status")
async def account_status(request: Request):
    token = request.headers.get("X-Admin-Token")
    if token != CONFIG.ADMIN_TOKEN:
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    account = request.query_params.get("account") or CONFIG.DEFAULT_ACCOUNT
    try:
        authorized = await multi_manager.is_authorized(account)
    except Exception:
        authorized = False
    return JSONResponse({"account": account, "authorized": authorized})